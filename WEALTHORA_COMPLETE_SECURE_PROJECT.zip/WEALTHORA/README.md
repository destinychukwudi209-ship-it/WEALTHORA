# WEALTHORA

WEALTHORA is a Next.js + TypeScript foundation for a Nigerian investment and wealth platform.

## Setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and configure Supabase.
4. Run the SQL in `supabase/schema.sql` in your Supabase project.
5. Run `npm run dev`.

## Security included in this foundation
- Supabase Auth integration points (passwords are never stored by this app).
- Server-side role checks for admin routes and API endpoints.
- Database Row Level Security policies and user ownership checks.
- Security headers, server-side input validation, API rate-limit helper.
- Transaction PIN verification design (store only a password hash; wire a managed hashing/KMS service before production).
- Audit log schema, withdrawal state controls, idempotency keys, account freeze fields.
- Environment secrets excluded from Git.

## Important production requirements
This repository is a substantial application foundation, not a live regulated financial service. Do not accept customer funds or promise returns until the business has obtained applicable Nigerian regulatory/legal approvals, completed KYC/AML, selected licensed payment/custody partners, implemented reconciliation, independent security testing, incident response, backups and operational controls. Configure and test email/SMS/2FA/payment providers before enabling those flows.

Investment tiers supplied by the owner are stored as draft/pending-approval terms. Projected values and task rewards are not treated as guaranteed returns or credited as money.

import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { wealth: { 950: '#081510', 900: '#10251b', 800: '#173526', 500: '#c6a65b' } } } }, plugins: [] };
export default config;
